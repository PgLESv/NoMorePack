execute unless score @s bacaped_riddle_nine_line_cat_var matches 10 run scoreboard players set @s bacaped_riddle_nine_line_cat_num 0
scoreboard players set @s bacaped_riddle_nine_line_cat_var 10

advancement revoke @s only minecraft:technical/riddle/line_nine_cat_variants/black
function minecraft:riddle/line_nine/counter