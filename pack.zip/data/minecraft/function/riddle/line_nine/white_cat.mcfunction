execute unless score @s bacaped_riddle_nine_line_cat_var matches 1 run scoreboard players set @s bacaped_riddle_nine_line_cat_num 0
scoreboard players set @s bacaped_riddle_nine_line_cat_var 1

advancement revoke @s only minecraft:technical/riddle/line_nine_cat_variants/white
function minecraft:riddle/line_nine/counter