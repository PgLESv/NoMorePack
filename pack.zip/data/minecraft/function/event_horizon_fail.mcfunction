# If you die in the void
scoreboard players set @s bac_eventhorizon 0
scoreboard players set @s bac_event_death 0
advancement revoke @s only minecraft:technical/below_void